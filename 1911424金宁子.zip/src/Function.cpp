#include "Function.h"
#include "Unit.h"
#include "Type.h"
#include <list>

extern FILE* yyout;

Function::Function(Unit *u, SymbolEntry *s,std::vector<SymbolEntry*> funcfpars_se)
{
    u->insertFunc(this);
    entry = new BasicBlock(this);
    sym_ptr = s;
    parent = u;
    this->funcfpars_se = funcfpars_se;
    printf("构造完了函数\n");
}

Function::~Function()
{
    auto delete_list = block_list;
    for (auto &i : delete_list)
        delete i;
    parent->removeFunc(this);
}

// remove the basicblock bb from its block_list.
void Function::remove(BasicBlock *bb)
{
    block_list.erase(std::find(block_list.begin(), block_list.end(), bb));
}

void Function::output() const
{
    printf("打印ll输出");
    FunctionType* funcType = dynamic_cast<FunctionType*>(sym_ptr->getType());
    Type *retType = funcType->getRetType();
    if(funcType->getParams().empty()){
        //fprintf(yyout, "empty\n");
        fprintf(yyout, "define %s %s() {\n", retType->toStr().c_str(), sym_ptr->toStr().c_str());
    }
    else{
        //fprintf(yyout, " not empty\n");
        fprintf(yyout, "define %s %s(", retType->toStr().c_str(), sym_ptr->toStr().c_str());
        //if(funcfpars_se.empty()){fprintf(yyout, "funcfpars_se是空的\n");}
        for(auto i = funcfpars_se.begin(); i < funcfpars_se.end(); i++){
            //fprintf(yyout, "进去for循环了 在Function.cpp中\n");
            if( i != funcfpars_se.begin())
            {
                fprintf(yyout, ", ");
            }
            //这里应该打印se而不是type
            fprintf(yyout, "%s %s", (*i)->getType()->toStr().c_str(), (*i)->toStr().c_str());
        }
        //fprintf(yyout, "出来循环了\n");
        fprintf(yyout, ") {\n");
    }
    std::set<BasicBlock *> v;
    std::list<BasicBlock *> q;
    q.push_back(entry);
    v.insert(entry);
    while (!q.empty())
    {
        auto bb = q.front();
        q.pop_front();
        bb->output();
        for (auto succ = bb->succ_begin(); succ != bb->succ_end(); succ++)
        {
            if (v.find(*succ) == v.end())
            {
                v.insert(*succ);
                q.push_back(*succ);
            }
        }
    }
    fprintf(yyout, "}\n");
    printf("function.cpp   end\n");
}
